<?php 

session_start();

// Include koneksi database
include '../php/koneksi.php';
// Include function
include '../php/function.php';


$dataBuku = sql("SELECT id, gambar, nama_buku, penulis FROM book");

$id = $_GET['id'];

?>


?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Icon -->
     <link rel="icon" href="Galeri/icon/books-icon.png">
    <title>Perpustakaan</title>
    
    <!-- link to css -->
    <link rel="stylesheet" href="../assets/css/index.css">
    
</head>
<body>
    <!-- nav -->
    <nav>

        <div class="logo">
            <img src="../assets/image/icon/books-icon.png" alt="icon">
            <p>PERPUSTAKAAN</p>
        </div>

        <div class="login">
        <?php if (isset($_SESSION['username']) || isset($_COOKIE['remember_token'])): ?>

        <a class="log-button" href="../php/logout.php">Logout (<?php echo $_SESSION['username'] ?? 'User'; ?>)</a>

        <?php else: ?>
        <a  class="log-button" href="../views/login.php">Login</a>
        <?php endif; ?>
        </div>

     </nav>

     <div class="element-plus"></div>


    <div class="layer">

        <header>
            <div class="slide-container">
                <div class="slide"><div class="slide-img slide-1"></div> </div>

                <div class="slide"><div class="slide-img slide-2"></div></div>

                <div class="slide"><div class="slide-img slide-3"></div></div>

                <div class="slide"><div class="slide-img slide-4"></div></div>

                <div class="slide"><div class="slide-img slide-1"></div> </div>

            </div>
        </header>
        
        <div class="container-library">

            <div class="title-library">
                <p>BOOK</p>
            </div>

            <div class="library">
                

            <?php foreach( $dataBuku as $buku) : ?>
                <div class="items-library">
                    <a href="../views/ebook.php?id=<?= $buku['id'] ?>">

                    <div class="image">
                        <img src="../assets/image/book/<?= $buku['gambar'] ?>" alt="buku"> <!-- Ambil dari database -->
                    </div>

                    <div class="desc-book">
                        <div class="penulis">
                            <p><?= $buku['penulis'] ?></p>   <!-- Ambil dari database -->
                        </div>

                        <div class="judul-buku">
                            <p><?= $buku['nama_buku'] ?></p> <!-- Ambil dari database -->
                        </div>
                    </div>
                    </a>
                </div>

                <?php endforeach;?>
                
            </div>

            
                <div class="link-library">
                    <a href="perpus.php">Lihat Selengkapnya...</a>
                </div>
        
        </div>


        <!-- Artikel -->

        <div class="container-blog">
            <div class="title-blog">
                <p>BLOG</p>
            </div>

            <div class="blog">
                <div class="items-blog">
                    <a href="/">

                    <div class="image">
                        <img src="Galeri/article/no-image.png" alt="blog">  <!-- Ambil dari database-->
                    </div>

                    <div class="desc-blog">
                        <div class="judul-blog">
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt blanditiis, officiis provident eius vitae, quam illo totam eligendi porro beatae quod minima odio facilis fugit veniam ad iure aperiam animi.</p>  <!-- Ambil dari database-->
                        </div>

                            <div class="date"> 04 Apr 2025</div> <!-- Ambil dari database-->
                    </div>
                </a>
                </div>

                 <div class="items-blog">
                    <a href="">                    <div class="image">
                        <img src="Galeri/article/no-image.png" alt="blog">  <!-- Ambil dari database-->
                    </div>

                    <div class="desc-blog">
                        <div class="judul-blog">
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt blanditiis, officiis provident eius vitae, quam illo totam eligendi porro beatae quod minima odio facilis fugit veniam ad iure aperiam animi.</p>  <!-- Ambil dari database-->
                        </div>

                            <div class="date"> 04 Apr 2025</div> <!-- Ambil dari database-->
                            </div>
                    </a>
                </div>

                <div class="items-blog">
                    <a href="">

                    <div class="image">
                        <img src="Galeri/article/no-image.png" alt="blog">  <!-- Ambil dari database-->
                    </div>

                    <div class="desc-blog">
                        <div class="judul-blog">
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt blanditiis, officiis provident eius vitae, quam illo totam eligendi porro beatae quod minima odio facilis fugit veniam ad iure aperiam animi.</p>  <!-- Ambil dari database-->
                        </div>

                        <div class="date"> 04 Apr 2025</div> <!-- Ambil dari database-->
                        </div>
                    </a>
                </div>

                <div class="items-blog">
                    <a href="">

                    <div class="image">
                        <img src="Galeri/article/no-image.png" alt="blog">  <!-- Ambil dari database-->
                    </div>

                    <div class="desc-blog">
                        <div class="judul-blog">
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt blanditiis, officiis provident eius vitae, quam illo totam eligendi porro beatae quod minima odio facilis fugit veniam ad iure aperiam animi.</p>  <!-- Ambil dari database-->
                        </div>

                        <div class="date"> 04 Apr 2025</div> <!-- Ambil dari database-->
                        </div>
                    </a>
                </div>

                <div class="items-blog">
                    <a href="">

                    <div class="image">
                        <img src="Galeri/article/no-image.png" alt="blog">  <!-- Ambil dari database-->
                    </div>

                    <div class="desc-blog">
                        <div class="judul-blog">
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt blanditiis, officiis provident eius vitae, quam illo totam eligendi porro beatae quod minima odio facilis fugit veniam ad iure aperiam animi.</p>  <!-- Ambil dari database-->
                        </div>

                        <div class="date"> 04 Apr 2025</div> <!-- Ambil dari database-->
                        </div>
                    </a>
                </div>

                <div class="items-blog">
                    <a href="">

                    <div class="image">
                        <img src="Galeri/article/no-image.png" alt="blog">  <!-- Ambil dari database-->
                    </div>

                    <div class="desc-blog">
                        <div class="judul-blog">
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt blanditiis, officiis provident eius vitae, quam illo totam eligendi porro beatae quod minima odio facilis fugit veniam ad iure aperiam animi.</p>  <!-- Ambil dari database-->
                        </div>

                        <div class="date"> 04 Apr 2025</div> <!-- Ambil dari database-->
                        </div>
                    </a>
                </div>

                <div class="items-blog">
                    <a href="">

                    <div class="image">
                        <img src="Galeri/article/no-image.png" alt="blog">  <!-- Ambil dari database-->
                    </div>

                    <div class="desc-blog">
                        <div class="judul-blog">
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt blanditiis, officiis provident eius vitae, quam illo totam eligendi porro beatae quod minima odio facilis fugit veniam ad iure aperiam animi.</p>  <!-- Ambil dari database-->
                        </div>

                        <div class="date"> 04 Apr 2025</div> <!-- Ambil dari database-->
                        </div>
                    </a>
                </div>
            </div>
            <!-- <div class="link-blog">
                <a href="/">Lihat Selengkapnya...</a>
            </div> -->

        </div>

        
    </div>
   

    <footer>
    <div class="title-footer">
      <img src="../assets/image/icon/books-icon.png" alt="Logo">
      <p>The <span>Syntax</span></p>
    </div>
  
    
    

    <div class="footer-container">
      <!-- Quick Link -->
      <div class="footer-container-list">
        <p>Quick Link</p>
        <ul>
          <li><a href="#">Book</a></li>
          <li><a href="#">Blog</a></li>
        </ul>
      </div>
  
      <!-- Social Media -->
      <div class="footer-container-list">
        <p>Social Media</p>
        <ul>
          <li><a href="#">Instagram</a></li>
          <li><a href="#">Twitter</a></li>
          <li><a href="#">LinkedIn</a></li>
        </ul>
      </div>
  
      <!-- Contact -->
      <div class="footer-container-list">
        <p>Contact</p>
        <ul>
          <li> <a href="mailto:kamu@email.com">Email: kamu@email.com</a></li>
          <li><a href="tel:+62812xxxx"> Phone: 0812-xxxxa</a> </li>
        </ul>
      </div>
    </div>

    <!-- copyright -->
    <div class="copyright">
       <p> <span>&copy;</span> 2025 The Syntax. All rights reserved.</p>
    </div>
</footer>
  


    <script src="../assets/js/script.js"></script>

</body>
</html>