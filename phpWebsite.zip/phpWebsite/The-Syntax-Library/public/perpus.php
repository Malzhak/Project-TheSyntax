<?php 
session_start();

include '../php/koneksi.php';
require '../php/function.php';


// $dataBuku = sql;


// pencarian buku
$keyword = isset($_GET['search']) ? $_GET['search'] : '';

$hasilKeyword =[];

if ($keyword){
  // ngambil dari database
  $stmt = $conn->prepare("SELECT id, gambar, nama_buku, penulis FROM book WHERE nama_buku LIKE ? OR penulis LIKE ?" );
  $likeKeyword = "%" . $keyword . "%";
  $stmt->bind_param("ss", $likeKeyword, $likeKeyword);
  $stmt->execute();
  $result = $stmt->get_result();

  while($row = $result->fetch_assoc()){
    if(stripos($row['nama_buku'], $keyword) !== false || stripos($row['penulis'], $keyword) !== false)
    {
      $hasilKeyword[] = $row;
    }
  }
    
  
} else{
  $stmt = $conn->prepare("SELECT id, gambar, nama_buku, penulis FROM book");
  $stmt->execute();
  $result = $stmt ->get_result();

  while($row = $result->fetch_assoc()){
    $hasilKeyword[] = $row;
  }

}

?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Icon -->
     <link rel="icon" href="Galeri/icon/books-icon.png">
    <title>Perpustakaan</title>
    
    <!-- link to css -->
    <link rel="stylesheet" href="../assets/css/book.css">

    
    
</head>
<body>
    <!-- nav -->
<nav>
  <div class="logo">
            <img src="../assets/image/icon/books-icon.png" alt="icon">
            <p>PERPUSTAKAAN</p>
        </div>

        <div class="login">
        <?php if (isset($_SESSION['username']) || isset($_COOKIE['remember_token'])): ?>

        <a class="log-button" href="../views/logout.php"><?php echo $_SESSION['username'] ?? 'User'; ?></a>

        <?php else: ?>
        <a  class="log-button" href="../views/login.php">Login</a>
        <?php endif; ?>
        </div>

     </nav>

     <div class="element-plus"></div>

<div class="container">
  <h1 class="judul-page">E-BOOK</h1>

  <form action="" method="get">
  <div class="search-bar">
    <input type="text" name="search" value="<?= htmlspecialchars($keyword) ?>" placeholder="Cari buku...">
  </div>

  <div class="rak-buku">
    
    <?php foreach($hasilKeyword as $buku) :?>
    <div class="buku-card">
      <div class="image">
      <img src="../assets/image/book/<?= $buku['gambar'];?>" alt="Cover Buku">
      </div>
      <h3><?= $buku['nama_buku']?></h3>
      <p><?= $buku['penulis']?></p>
      <a href="../views/ebook.php?id=<?= $buku['id'] ?>">Detail</a>
    </div>

    <?php endforeach; ?>
   
  </div>
</div>

<footer>
    <div class="title-footer">
      <img src="../assets/image/icon/books-icon.png" alt="Logo">
      <p>The <span>Syntax</span></p>
    </div>
  
    
    

    <div class="footer-container">
      <!-- Quick Link -->
      <div class="footer-container-list">
        <p>Quick Link</p>
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="perpus.php">Perpustakaan</a></li>
        </ul>
      </div>
  
      <!-- Social Media -->
      <div class="footer-container-list">
        <p>Social Media</p>
        <ul>
          <li><a href="https://www.instagram.com/">Instagram</a></li>
          <li><a href="https://www.twitter.com/">Twitter</a></li>
          <li><a href="https://www.id.linkedin.com/">LinkedIn</a></li>
        </ul>
      </div>
  
      <!-- Contact -->
      <div class="footer-container-list">
        <p>Contact</p>
        <ul>
          <li> <a href="mailto:kamu@email.com">Email: kamu@email.com</a></li>
          <li><a href="tel:+62812xxxx"> Phone: 0812-xxxxa</a> </li>
        </ul>
      </div>
    </div>

    <!-- copyright -->
    <div class="copyright">
       <p> <span>&copy;</span> 2025 The Syntax. All rights reserved.</p>
    </div>
</footer>
  


</body>
</html>