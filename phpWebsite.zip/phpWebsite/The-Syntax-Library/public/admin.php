<?php

session_start();

include '../php/koneksi.php';
include '../php/function.php';


$dataUser= sql("SELECT * FROM users" ); // users
$dataBuku= sql("SELECT * FROM book" ); // book

?>



<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Panel - Berita</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background: #e6f2ff;
    }

    header {
      background-color: #003366;
      color: white;
      padding: 20px;
      text-align: center;
    }

    main {
      padding: 20px;
      max-width: 1000px;
      margin: auto;
    }

    h2 {
      margin-top: 30px;
      color: #003366;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background: #fff;
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
      margin: 50px 0;
    }

    th, td {
      padding: 12px 15px;
      text-align: left;
    }

    th {
      background-color: #0059b3;
      color: white;
    }

    tr:hover {
      background-color: #eef3f7;
    }

    .btn {
      background-color: #0073e6;
      color: white;
      padding: 6px 12px;
      border: none;
      border-radius: 4px;
      text-decoration: none;
      white-space: inheri;
      font-size: 14px;
      margin: 5px;
    }

    .btn:hover {
      background-color: #005bb5;
    }

    .btn-logout{
      background-color: #e60000;
    }

    .btn-logout:hover {
      background-color: #b30000;
    }

    .logout {
      display: block;
      margin-top: 40px;
      text-align: center;
    }
  </style>
</head>
<body>

  <header>
    <h1>Selamat datang <? echo $dataUser['username'] ; ?> </h1>
    
  </header>

  <main>
      <h2>Data Users</h2>
      <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Email</th>
          <th>Name</th>
          <th>Role</th>
          <th>Tanggal</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>

        <?php foreach($dataUser as $user) :?>
            <tr>
        <td><?=$user['id']?></td>
        <td><?=$user['username']?></td>
        <td><?=$user['email']?></td>
        <td><?=$user['role']?></td>
        <td><?=$user['created_at']?>
        
        <td>
            <a class="btn" href="../views/edit.php?id=<?=$user['id']?>">Edit</a>
            <a class="btn" onclick="return confirm('konfirmasi untuk hapus user ini!')" href="../php/delete.php?id=<?php echo $user['id'] ?>">Hapus</a>
        </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>




      <h2>Data Buku</h2>

    <table>
        <thead>
          <tr>
          
            
         
            <th><a class="btn" href="../views/tambahBuku.php">Tambah</a></th>
            <th>ID</th>
            <th>Foto</th>
            <th>Nama Buku</th>
            <th>Penulis</th>
            <th>Tahun</th>
            <th>Deskripsi</th>
            <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            
            <?php foreach($dataBuku as $buku) :?>
            <tr>
              <td></td>
            <td><?=$buku['id'] ?></td>
            <td><img src="../assets/image/book/<?=$buku['gambar']?>" alt="Cover Buku" width="50"></td>
            <td><?=$buku['nama_buku']?></td>
            <td><?=$buku['penulis']?></td>
            <td><?=$buku['tahun']?></td>
            <td><?=$buku['sinopsis']?></td>
    
            <td>
                <a class="btn" href="../views/editBuku.php?id=<?=$buku['id']?>">Edit</a>
                <a class="btn" onclick="return confirm('konfirmasi untuk hapus user ini!')" href="../php/delete.php?id=<?php echo $buku['id'] ?>">Hapus</a>
               
              </td>
              
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="logout">
      <a class="btn btn-logout" href="../php/logout.php" >Logout</a>
    </div>
  </main>

</body>
</html>
