<?php 
include '../php/koneksi.php';
include '../views/tambahBuku.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['submit'])) {
       $namaBuku= trim(strip_tags($_POST['judul']));
       $penulis= trim(strip_tags($_POST['penulis']));
       $terbit= trim(strip_tags($_POST['terbit']));
       $desc= trim(strip_tags($_POST['desc']));
       $link = trim($_POST['link']); 
       $namaFile= trim(strip_tags($_POST['nama_file']));
  
// upload gambar
$namaFile = $_FILES['gambar']['name'];
$tmp_name = $_FILES['gambar']['tmp_name'];
$folderTujuan = "../assets/image/book/";

// cek file
if(!empty($namaFile)){
    $namaBaru = uniqid().'_' . basename($namaFile); //buat nama baru
    $pathSimpan = $folderTujuan . $namaBaru;

    //massukkan data
    if(move_uploaded_file($tmp_name, $pathSimpan)){
        $stmt = $conn -> prepare("INSERT INTO book (gambar, nama_buku, penulis, sinopsis, tahun, link) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $namaBaru, $namaBuku, $penulis, $desc, $terbit, $link);
        
        if($stmt ->execute()){
            header("Location: ../public/admin.php");
            exit;
        }
    }
    
}


    }
}
?>