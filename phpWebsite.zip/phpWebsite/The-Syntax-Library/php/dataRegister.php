<?php  
session_start();

include '../php/koneksi.php';

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['submit'])) {
        $email = trim(strip_tags($_POST['email']));
        $password = trim(strip_tags($_POST['password']));
        $username = trim(strip_tags($_POST['username']));
        $hashPassword = password_hash($password, PASSWORD_DEFAULT);


        if (empty($email)){
            $error = 'Note: Email tidak boleh kosong!';
        } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Note: Format email tidak valid!';
        } else if (empty($hashPassword)){
            $error = 'Note: Password tidak boleh kosong!';
        } else if (strlen($password) < 6) {
            $error = 'Note: Password minimal 6 karakter!';
        } else if (empty($username)){
            $error = 'Note: Nama tidak boleh kosong!';
        } else{


// cek apakah email sudah ada
$checkEmail = $conn->prepare("SELECT id FROM users WHERE email = ?");
$checkEmail->bind_param("s", $email);
$checkEmail->execute();
$checkEmail->store_result();

if ($checkEmail->num_rows > 0) {
    // email sudah terdaftar
    $error ="Note: Email sudah digunakan. Silakan gunakan email lain.";
} else {
    // email belum ada, insert data baru
    $stmt = $conn->prepare("INSERT INTO users (email, password, username) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $email, $hashPassword, $username);
    $stmt->execute();
    $stmt->close();

    if(empty($error)){
        header("Location: ../public/index.php");
    };

  
}
}  
}
}

if (isset($_POST['batal'])) {
    header("Location: ../public/index.php");
    exit();
}




?>