<?php 

$host = "localhost";    // Host 
$user = 'root';         //user
$pass = '';             //password
$dbname = 'webdb';      //database

// membuat koneksi ke database
$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
} else {
    // echo "<script>alert('aman bos');</script>";
}


?>
