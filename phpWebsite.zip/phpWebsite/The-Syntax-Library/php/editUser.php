<?php
include '../php/koneksi.php';
include '../php/function.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $id = $_POST['id'];
  $username = trim($_POST['username']);
  $mail = trim($_POST['mail']);
  $password = $_POST['pass'];



  // Update dengan atau tanpa password
  if (!empty($password)) {
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, password = ? WHERE id = ?");
    $stmt->bind_param("sssi", $username, $mail, $hashedPassword, $id);
  } else {
    $error = "password tidak boleh kosong";
    header("Location: ../views/edit.php?id=$id&error=$error");
    exit;
  }

  if ($stmt->execute()) {
    header("Location: ../public/admin.php?update=success");
    exit;
  } else {
    echo "Gagal menyimpan perubahan.";
  }
} else {
  echo "Akses tidak valid.";
}
?>
