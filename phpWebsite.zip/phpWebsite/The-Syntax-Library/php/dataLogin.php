<?php 
session_start();
  

// menghubungkan ke database
include '../php/koneksi.php';

$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST'){

    //cek cookie
    if (isset($_COOKIE['remember_token'])){

        $token = $_COOKIE['remember_token'];

        $stmt = $conn -> prepare("SELECT id, username FROM users WHERE token = ?");
        $stmt -> bind_param("s", $token);
        $stmt -> execute();
        $stmt -> store_result();

        // jika ada hasil ditemukan
        if ($stmt -> num_rows() > 0){

            // menenaruh nilai stmt ke tempat masing masing
            $stmt -> bind_result($id, $username);
            $stmt -> fetch();

            $_SESSION ['id'] = $id;
            $_SESSION ['username'] = $username;

            echo"<script> alert 'Aman'</script>";

        }
    }



    // jika form di submit
    if (isset($_POST['submit'])) {
        $login = trim(strip_tags($_POST['username']));

        $password = strip_tags($_POST['password']);

        

        // validasi input
        if(empty($password)){
            $error = 'Note: Password tidak boleh kosong!';
        } else if (empty($login)){
            $error = 'Note: username atau email tidak boleh kosong!';
        } else{ 

        
        // cek apakah email dan username sudah ada
        $stmt = $conn -> prepare("SELECT id, password, username FROM users WHERE email = ? OR username =?");
        $stmt -> bind_param("ss", $login, $login);
        $stmt -> execute();
        $stmt -> store_result();
        
        // jika ada hasil ditemukan
        if ( $stmt -> num_rows() > 0){
            // menenaruh nilai stmt ke tempat masing masing
            $stmt -> bind_result($id, $hashPassword, $username);
            $stmt -> fetch();


            // membandingkan password
            if (password_verify($password, $hashPassword)){

                $_SESSION ['id'] = $id;

                $_SESSION ['username'] = $username;

               if (isset($_POST['remember']) && $_POST['remember'] == 'on'){

                // membuat isi token acak
                $rememberToken = bin2hex(random_bytes(32));

                // menyimpan token selama 30 hari 
                setcookie('remember_token',$rememberToken, time() + (86400 * 30), "/" , "", false , true); // nama cookie, isi cookie, waktu kadaluarsa, path, domain, secure(http/https), httponly

                // menyimpan token ke database
                $stmt = $conn -> prepare("UPDATE users SET token = ? WHERE id = ?");
                $stmt -> bind_param("ss", $rememberToken, $id);
                $stmt -> execute();


               }

               header("Location: ../public/index.php");

            }else {
                $error = 'Note: Password salah!'; 

            }

    } else {

        $error = 'Note: akun tidak ditemukan!';;
    }

    
}
$conn->close();
}


if (isset($_POST['batal'])) {
    header("Location: ../public/index.php");
    exit();
}

}
?>