<?php
session_start();

// Hapus semua session
session_unset();
session_destroy();

// Hapus cookie remember_token
if (isset($_COOKIE['remember_token'])) {
    setcookie('remember_token', '', time() - 3600, "/"); // Hapus cookie
}

header("Location: ../public/index.php"); // Redirect ke halaman login
// Setelah logout, munculkan alert dan redirect pakai JavaScript
// echo "<script>
//     alert('Logout berhasil!');
//     window.location.href = '..login.php';
// </script>";
exit();
?>
