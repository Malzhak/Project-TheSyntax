<?php 

include '../php/koneksi.php';
include '../php/function.php';

echo ' hellos';

if (isset($_POST['submit'])){
    $id = htmlspecialchars($_POST['id']);
    $judul = htmlspecialchars( $_POST['judul']);
    $penulis =  htmlspecialchars($_POST['penulis']);
    $desc = htmlspecialchars($_POST['desc']);
    $terbit = htmlspecialchars($_POST['terbit']);
    
    
    
    $namaFile = $_FILES['gambar']['name'];
    $tmpName = $_FILES['gambar']['tmp_name'];
    $folderTujuan = '../assets/image/book/' ;
    
    
    if(!empty($namaFile)){
        $namaBaru = uniqid().'_' . basename($namaFile); //buat nama baru
        $pathSimpan = $folderTujuan . $namaBaru;

        // update semua data
    if(move_uploaded_file($tmpName, $pathSimpan)){
        $stmt = $conn -> prepare("UPDATE book SET gambar = ?, nama_buku = ?, penulis = ?, sinopsis = ?, tahun = ? WHERE id = ?");
        $stmt->bind_param("ssssss", $namaBaru, $judul, $penulis, $desc, $terbit,  $id);
    }else {
        echo "<script>alert('Gagal mengunggah gambar!'); window.history.back();</script>";
        exit;
    }
    
  } else {
     // Jika gambar tidak diganti, update data selain gambar
     $stmt = $conn->prepare("UPDATE book SET nama_buku = ?, penulis = ?, tahun = ?, sinopsis = ? WHERE id = ?");
     $stmt->bind_param("ssssi", $judul, $penulis, $tahun, $deskripsi, $id);
  }

  if($stmt->execute()){
    header("Location: ../public/admin.php?update=success");
    exit;
  }else {
    echo "<script>alert('Gagal menyimpan perubahan!'); window.history.back();</script>";
}
}




?>