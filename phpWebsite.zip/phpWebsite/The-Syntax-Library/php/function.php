<?php 

include 'koneksi.php';
include 'koneksi.php';



// mengambil data dari database
function sql($query){
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];

    while ($row = mysqli_fetch_assoc($result)){
        $rows[] = $row;
    }
    return $rows;
}

// 
function sqlPre($query, $param){
    global $conn;
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i',$param);
    $stmt->execute();
    $result = $stmt->get_result();
   

    return  $result->fetch_assoc();


}


?>