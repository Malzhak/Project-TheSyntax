<?php
include '../php/koneksi.php';

if (isset($_GET['id'])) {
  $id = $_GET['id'];

  // Cek di tabel users
  $checkUser = $conn->prepare("SELECT id FROM users WHERE id = ?");
  $checkUser->bind_param("i", $id);
  $checkUser->execute();
  $resultUser = $checkUser->get_result();

  if ($resultUser->num_rows > 0) {
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: ../public/admin.php?delete=success");
    exit;
  }

  // Cek di tabel book
  $checkBook = $conn->prepare("SELECT id FROM book WHERE id = ?");
  $checkBook->bind_param("i", $id);
  $checkBook->execute();
  $resultBook = $checkBook->get_result();

  if ($resultBook->num_rows > 0) {
    $stmt = $conn->prepare("DELETE FROM book WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: ../public/admin.php?delete=success");
    exit;
  }

  echo "Data tidak ditemukan di kedua tabel.";
} else {
  echo "ID tidak ditemukan.";
}
?>
