// slide otomatis
let x = 0;
const slides = document.querySelector('.slide-container');
const totalSlides = document.querySelectorAll('.slide').length;

function slideMove(step){
    x += step;
    slides.style.transition = 'transform 0.8s ease-in-out';
    slides.style.transform = `translateX(-${x * 100}%`;


    if (x >= totalSlides - 1 ){
        setTimeout( () => {
            slides.style.transition = 'none';
            x = 0;
            slides.style.transform = 'translateX(0)';
        }, 800)
    }

};

setInterval(() => slideMove(1), 3000);