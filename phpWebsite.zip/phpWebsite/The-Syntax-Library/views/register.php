<?php include '../php/dataRegister.php';?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- link css -->
     <link rel="stylesheet" href="../assets/css/re&lo.css">

    <!-- icon -->
    <link rel="icon" href="../assets/image/icon/books-icon.png">

    <title>Perpustakaan</title>
</head>
<body>

    <div class="container">
        <div class="box-container">
            <div class="title-container
            ">
            <h1>REGISTRER</h1> 
        <img src="../assets/image/icon/circle-user-solid.svg" alt="">
    </div>

        
            <form class="container-form" action="" method="post">

            <?php
                echo "<p style='color:red; margin-top:-25px; font-size:.8rem;'>$error</p>";
            
            ?>
            
                <p class="email">
                    
                    <label for="email">Email</label>
                    <input type="email" placeholder="Masukkan Email..." id="email" 
                    name="email" required>
               
                </p>

                <p class="username">
                    <label for="username">Username</label>
                    <input type="text" placeholder="Masukkan username..." id="username" 
                    name="username" required>
                </p>

                <p>
                    <label for="pass">Password</label>
                    <input type="password" placeholder="Masukkan password..." id="pass" 
                    name="password" required>

                <div class="bottom-container">
    





                    <div class="button">
                    <input type="submit" value="Selesai" name="submit">

                    <input type="submit" value="Batal" name="batal">
                    
                </div>

                </div>
          
                <div class="login-page">
                <p >Sudah mempunyai Akun? <a href="login.php">Log In akun</a> </p>
                </div>
            </form>
        </div>
    </div>
    </div>
    
</body>
</html>