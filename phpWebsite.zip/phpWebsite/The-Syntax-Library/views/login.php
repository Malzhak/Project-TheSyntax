<?php include '../php/dataLogin.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- link css -->
     <link rel="stylesheet" href="../assets/css/re&lo.css">

    <!-- icon -->
    <link rel="icon" href="../assets/image/icon/books-icon.png">

    <title>Perpustakaan</title>
</head>
<body>

    <div class="container">
        <div class="box-container">
            <div class="title-container tc">
            <h1>LOGIN</h1> 
        <img src="../assets/image/icon/circle-user-solid.svg" alt="">
    </div>

        
            <form class="container-form focon" action="" method="post">

            <?php
                echo "<p style='color:red; margin-top:-25px; font-size:.8rem;'>$error</p>";
            ?>
            

                <p>
                    <label for="username">Username</label>
                    <input type="text" placeholder="Masukkan username..." id="username" 
                    name="username" required>
                </p>

                <p>
                    <label for="pass">Password</label>
                    <input type="password" placeholder="Masukkan password..." id="pass" 
                    name="password" required>

                <div class="bottom-container bottom-container-login">

                    
    
                <div class="remember">
                        <input type="checkbox" name="remember"  id="check">
                        <label for="check">Remember me</label >
                    </div>
                    

                    <div class="button">
                    <input type="submit" value="Selesai" name="submit">

                    <input type="submit" value="Batal" name="batal">
                    
                </div>

                </div>

                <!-- <div class="foget-pass">
    
                </div> -->
                
                <div class="login-page">
                <p >Belum mempunyai Akun? <a href="register.php">Buat akun</a> </p>
                </div>
            </form>
        </div>
    </div>
    </div>
    
</body>
</html>