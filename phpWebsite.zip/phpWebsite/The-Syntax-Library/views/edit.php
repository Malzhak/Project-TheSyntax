<?php 
include '../php/koneksi.php';
include '../php/function.php';

$id = $_GET['id']; 


$stmt = $conn -> prepare( "SELECT * FROM users WHERE id = ?");
$stmt -> bind_param("i", $id);
$stmt -> execute();
$result = $stmt -> get_result();
$ganti = $result -> fetch_assoc();

?>



<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Edit User</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }

    .container {
      background-color: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      width: 100%;
      max-width: 400px;
    }

    h2 {
      margin-bottom: 20px;
      font-size: 24px;
      color: #333;
      text-align: center;
    }

    label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
      color: #333;
    }

    input{
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    button {
      width: 100%;
      padding: 10px;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 4px;
      font-size: 16px;
      cursor: pointer;
    }

    button:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Edit User</h2>
    <form action="../php/editUser.php" method="POST">
        <input type="hidden" name="id" value="<?=$ganti['id']?>" />

      <label for="nama">Nama</label>
      <input type="text" id="nama" name="username" value="<?=$ganti['username']?>"  />

      <label for="email">Email</label>
      <input type="email" id="email" name="mail" value="<?=$ganti['email']?>"  />

      <label for="pass">Ganti Password</label>
      <input type="text" id="pass" name="pass" value="" />

      <button type="submit">Simpan Perubahan</button>
    </form>
  </div>
</body>
</html>