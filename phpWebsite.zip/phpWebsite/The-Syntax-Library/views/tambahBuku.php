<?php 
include '../php/koneksi.php';
include '../php/function.php';



?>



<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Tambah Buku</title>
  <style>
   
    
    .container {
      margin: auto;
      background-color: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      width: 80%;
      max-width: 400px;
    }

    h2 {
      margin-bottom: 20px;
      font-size: 24px;
      color: #333;
      text-align: center;
    }

    label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
      color: #333;
    }

    input{
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    textarea {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    button {
      width: 100%;
      padding: 10px;
      margin: 10px;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 4px;
      font-size: 16px;
      cursor: pointer;
    }

    button:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>

<main>
  <div class="container">
    <h2>Tambah Buku</h2>

    <form action="../php/tambahItemBuku.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?=$ganti['id']?>" />

      <label for="nama">Judul</label>
      <input type="text" id="nama" name="judul"/>
      
      <label>Penulis</label>
      <input type="text" name="penulis" required>

      <label>Terbitkan</label>
    <input type="text" name="terbit" required>

      <label>Nama File (gambar*beserta format):</label>
    <input type="text" name="nama_file" placeholder="contoh: buku-of_the year.jpg"  accept="../assets/image/book/*" required>

    <label>Link</label>
    <input type="text" name="link" required>


      <label>Deskripsi</label>
      <textarea name="desc"  rows="12"></textarea>

    <label>Pilih Gambar:</label><br>
    <input type="file" name="gambar" accept="image/*" >

    <button type="submit" name="submit">Upload</button>

      <button type="submit" name="batal">Batalkan</button>
      
    </form>
  </div>

  
</body>
</html>