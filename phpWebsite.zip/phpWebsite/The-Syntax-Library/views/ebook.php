<?php 
include '../php/koneksi.php';
include '../php/function.php';

$id = $_GET['id'];

$ebook =sqlPre("SELECT * FROM book WHERE id = ?",$id);
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Detail Buku</title>
  <link rel="stylesheet" href="../assets/css/ebook.css"> <!-- Pakai CSS yang sama biar konsisten -->
</head>
<body>

  <div class="container">

    <img src="../assets/image/book/<?= $ebook['gambar']?>" alt="Cover Buku">

    <div class="detail-info">
      <h2></h2>
      <p><strong>Penulis:</strong><?= $ebook['penulis']?></p>
      <p><b>Tahun Terbit:</b> <?= $ebook['tahun']?></p>
      <div class="desc-container">
      <p><b>Deskripsi:</b></p>
      <div class="desc">
      <p>"<?= $ebook['sinopsis']?>"</p>
    </div>
      </div>

     
      <a href="<?= $ebook['link']?>"><input type="submit" nama = 'submit' value="Baca"></a>
    </div>
  </div>

  <div style="text-align: center;">
    <a class="back-button" href="../public/index.php">← Kembali</a>
  </div>

</body>
</html>
