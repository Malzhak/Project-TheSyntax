-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2025 at 12:15 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `judul_berita` text NOT NULL,
  `desc_berita` longtext NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `id` int(11) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `nama_buku` varchar(100) NOT NULL,
  `penulis` varchar(50) NOT NULL,
  `sinopsis` longtext NOT NULL,
  `tahun` text NOT NULL,
  `link` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`id`, `gambar`, `nama_buku`, `penulis`, `sinopsis`, `tahun`, `link`) VALUES
(7, '680b3cb5c4b7f_Judul Teman.avif', 'Teman', 'Jounatan & Guntur Alam', 'Kisah misteri pembunuhan di sekolah, arwah korban yang menuntut balas, dan teror tak kasatmata pada teman-teman Jou Bergabunglah dalam petualangan seram Jou menghadapi sesuatu yang penuh dendam dan haus darah, tanpa bisa membedakan lawan atau kawan', '2023', ''),
(9, '680b40db94f48_HaryyPotter.jpg', 'Haryy Potter The Complete Collection', 'J. K. rowling', 'Dikenal di dunia sihir sebagai \' Si Anak yang Hidup \' setelah menjadi satu-satunya yang berhasil selamat dari Kutukan Pembunuhan, yang dicoba dilakukan Voldemort saat Harry masih bayi, setelah kedua orang tuanya dibunuh.', '2021', 'https://kvongcmehsanalibrary.wordpress.com/wp-content/uploads/2021/07/harrypotter.pdf'),
(11, '680b43cdc5c81_the monk.jpg', 'The Monk Who Sold His Ferrari', 'Robin S. Sharma', 'The Monk Who Sold His Ferrari has been a very special project, brought to\r\nfruition through the efforts of some very special people. I am deeply grateful\r\nto my superb production team and to all those whose enthusiasm and energy\r\ntransformed my vision of this book into reality, especially my family at Sharma\r\nLeadership International.', '2021', 'https://ati.dae.gov.in/ati12052021_5.pdf'),
(12, '680b44a7a74e9_TIK.jpg', 'Teknologi Informasi Dan Komunikasi untuk SMP kelas XI', 'Julianto Arif Setiadi', 'Dalam buku ini, kamu akan mempelajari teknologi komputer yang berbasis open\r\nsource. Open source merupakan teknologi komputer yang dapat diperoleh secara gratis\r\ndan dapat dikembangkan oleh orang-orang yang memahami bahasa pemrograman.', '2010', 'https://www.pkbmanggrek.sch.id/upload/file/63834640Ket.KomputerIX-2-dikompresi.pdf'),
(13, '680b4545873d4_NETBEANS.jpg', 'Dasar - Dasar Pemograman Java Menggunakan NETBEANS', 'Dwi Hastuti', 'Buku ini dapat dimanfaatkan untuk pemula dalam memelajari dasardasar pemrograman Java. Masing-masing materi disajikan secara\r\nsistematis disertai contoh agar lebih mudah dipahami dan dipelajari.', '2020', 'https://repository.unipasby.ac.id/id/eprint/7181/1/Dwi%20Hastuti%20Yusril%20Arief%20-%20Dasar-Dasar%20Pemrograman%20Java%20Untuk%20Pemula%20Menggunakan%20Netbeans_watermark.pdf'),
(14, '680b459e32722_simulasi digital.jpg', 'Simulasi DIgital', 'Eko Subiyantoro', 'Buku teks “Simulasi Digital” ini disusun berdasarkan tuntutan paradigma\r\npengajaran dan pembelajaran kurikulum 2013diselaraskan berdasarkan\r\npendekatan model pembelajaran yang sesuai dengan kebutuhan belajar\r\nkurikulum abad 21, yaitu pendekatan model pembelajaran berbasis peningkatan\r\nketerampilan proses sains.', '2013', 'https://repositori.kemdikbud.go.id/8857/1/C2-Simulasi-Digital-X-1.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `username` varchar(150) NOT NULL,
  `token` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `role`, `created_at`, `username`, `token`) VALUES
(25, 'alamqlasa@gmail.com', '$2y$10$xDjOJLX/H4HQRklJQETOKO9Ju6YcukRuslNmkrprGxcZfuuPM7sM2', 'user', '2025-04-23 00:51:14', '123491qq', ''),
(27, 'wis68@gmail.com', '$2y$10$0qrTWBnuB50nYTRcnbusE.6VMXD74Mv1KCT.ztH7q7VvtzPG.8GNW', 'user', '2025-04-23 01:53:13', 'Gilaa', ''),
(30, 'mzul7091@gmail.com', '$2y$10$gg5fOf6nmIJT4STptf5EKeI7qYivDzIhAFisaXryYrkgMtSoz3RQO', 'user', '2025-04-23 05:20:48', 'malik', '809e30f5860d87fe9f8a49603a82217163c6c46d28cda091fde8549df4ed4b94'),
(36, 'hello@gmail.com', '$2y$10$m2uz.jXoY0aPyh9K6hJse.s4UqjS6v/tD2TXb1DHWY170XAUrR.hq', 'user', '2025-04-25 09:48:58', 'Hell', '1ba4ae7925287d822911af8695ef22c81bee4f3009e87bce47ad1f037ca7e21f');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
